
#include <bits/stdc++.h>
using namespace std;

// =============== BST NODE (FOR TOP STUDENTS) ===============
struct BSTNode {
    string id, name;
    double cgpa;
    BSTNode* left;
    BSTNode* right;

    BSTNode(string i, string n, double c) : id(i), name(n), cgpa(c), left(nullptr), right(nullptr) {}
};

// =============== STUDENT NODE (LINKED LIST) ===============
struct StudentNode {
    string id;
    string name;
    string email;
    double cgpa;
    int semester;
    vector<string> enrolledCourses;
    StudentNode* next;

    StudentNode(string i, string n, string e, double c, int s) {
        id = i;
        name = n;
        email = e;
        cgpa = c;
        semester = s;
        next = nullptr;
    }

    void display() {
        cout << "\n========== STUDENT PROFILE ==========\n";
        cout << "ID: " << id << "\n";
        cout << "Name: " << name << "\n";
        cout << "Email: " << email << "\n";
        cout << "CGPA: " << fixed << setprecision(2) << cgpa << "\n";
        cout << "Semester: " << semester << "\n";
        cout << "Enrolled Courses: ";
        if (enrolledCourses.size() == 0) {
            cout << "None\n";
        } else {
            for (int i = 0; i < enrolledCourses.size(); i++) {
                cout << enrolledCourses[i] << " ";
            }
            cout << "\n";
        }
        cout << "====================================\n";
    }
};

// =============== STUDENT LINKED LIST ===============
class StudentList {
public:
    StudentNode* head;

    StudentList() {
        head = nullptr;
    }

    void addStudent(string id, string name, string email, double cgpa, int sem) {
        StudentNode* newNode = new StudentNode(id, name, email, cgpa, sem);
        if (head == nullptr) {
            head = newNode;
        } else {
            StudentNode* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    StudentNode* findStudent(string id) {
        StudentNode* temp = head;
        while (temp != nullptr) {
            if (temp->id == id) {
                return temp;
            }
            temp = temp->next;
        }
        return nullptr;
    }

    bool deleteStudent(string id) {
        if (head == nullptr) return false;

        if (head->id == id) {
            StudentNode* temp = head;
            head = head->next;
            delete temp;
            return true;
        }

        StudentNode* temp = head;
        while (temp->next != nullptr) {
            if (temp->next->id == id) {
                StudentNode* toDelete = temp->next;
                temp->next = temp->next->next;
                delete toDelete;
                return true;
            }
            temp = temp->next;
        }
        return false;
    }

    void displayAll() {
        StudentNode* temp = head;
        while (temp != nullptr) {
            cout << "ID: " << temp->id << " | Name: " << temp->name 
                 << " | CGPA: " << fixed << setprecision(2) << temp->cgpa << "\n";
            temp = temp->next;
        }
    }

    int getCount() {
        int count = 0;
        StudentNode* temp = head;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    ~StudentList() {
        StudentNode* current = head;
        while (current != nullptr) {
            StudentNode* next = current->next;
            delete current;
            current = next;
        }
    }
};

// =============== COURSE CLASS WITH QUEUE (WAITLIST) ===============
class Course {
public:
    string code;
    string name;
    int credits;
    int capacity;
    int enrolled;
    vector<string> prerequisites;
    queue<string> waitlist;

    Course() {
        credits = 0;
        capacity = 0;
        enrolled = 0;
    }
    
    Course(string c, string n, int cr, int cap) {
        code = c;
        name = n;
        credits = cr;
        capacity = cap;
        enrolled = 0;
    }

    bool isFull() {
        return enrolled >= capacity;
    }

    void addToWaitlist(string studentId) {
        waitlist.push(studentId);
        cout << "Course is full. Added to waitlist (Position: " << waitlist.size() << ")\n";
    }

    string getNextFromWaitlist() {
        if (!waitlist.empty()) {
            string id = waitlist.front();
            waitlist.pop();
            return id;
        }
        return "";
    }

    void display() {
        cout << "[" << code << "] " << name << "\n";
        cout << "  Credits: " << credits << " | Students: " << enrolled << "/" << capacity;
        if (isFull()) {
            cout << " [FULL]";
        }
        cout << "\n";
        cout << "  Waitlist: " << waitlist.size() << " students\n";
        cout << "  Prerequisites: ";
        if (prerequisites.size() == 0) {
            cout << "None\n";
        } else {
            for (int i = 0; i < prerequisites.size(); i++) {
                cout << prerequisites[i] << " ";
            }
            cout << "\n";
        }
    }
};

// =============== UNDO OPERATION (STACK) ===============
struct UndoOperation {
    string type;
    string studentId;
    string courseCode;
};

// =============== BST CLASS (FOR TOP STUDENTS) ===============
class StudentBST {
private:
    BSTNode* root;

    BSTNode* insertBST(BSTNode* node, string id, string name, double cgpa) {
        if (!node) return new BSTNode(id, name, cgpa);
        if (cgpa >= node->cgpa) {
            node->right = insertBST(node->right, id, name, cgpa);
        } else {
            node->left = insertBST(node->left, id, name, cgpa);
        }
        return node;
    }

    void inorderBST(BSTNode* node, vector<pair<string, double>>& result, int& count) {
        if (!node || count >= 10) return;
        inorderBST(node->right, result, count);
        if (count < 10) {
            result.push_back({node->name, node->cgpa});
            count++;
        }
        inorderBST(node->left, result, count);
    }

    void deleteBST(BSTNode* node) {
        if (!node) return;
        deleteBST(node->left);
        deleteBST(node->right);
        delete node;
    }

public:
    StudentBST() : root(nullptr) {}

    void insert(string id, string name, double cgpa) {
        root = insertBST(root, id, name, cgpa);
    }

    vector<pair<string, double>> getTop10() {
        vector<pair<string, double>> result;
        int count = 0;
        inorderBST(root, result, count);
        return result;
    }

    void clear() { deleteBST(root); root = nullptr; }
    ~StudentBST() { deleteBST(root); }
};

// =============== FILE MANAGER ===============
class FileManager {
public:
    static void saveStudents(StudentList& students, string filename) {
        ofstream file(filename);
        StudentNode* temp = students.head;
        while (temp) {
            file << temp->id << "|" << temp->name << "|" << temp->email << "|" 
                 << temp->cgpa << "|" << temp->semester << "\n";
            temp = temp->next;
        }
        file.close();
        cout << "Students saved to " << filename << "\n";
    }

    static void loadStudents(StudentList& students, string filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "File not found!\n";
            return;
        }
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string id, name, email, cgpa_str, sem_str;
            getline(ss, id, '|');
            getline(ss, name, '|');
            getline(ss, email, '|');
            getline(ss, cgpa_str, '|');
            getline(ss, sem_str, '|');
            
            if (!id.empty()) {
                students.addStudent(id, name, email, stod(cgpa_str), stoi(sem_str));
            }
        }
        file.close();
        cout << "Students loaded from " << filename << "\n";
    }

    static void saveCourses(vector<Course>& courses, string filename) {
        ofstream file(filename);
        for (auto& c : courses) {
            file << c.code << "|" << c.name << "|" << c.credits << "|" 
                 << c.capacity << "|" << c.enrolled << "\n";
        }
        file.close();
        cout << "Courses saved to " << filename << "\n";
    }

    static void loadCourses(vector<Course>& courses, string filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "File not found!\n";
            return;
        }
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string code, name, credits_str, capacity_str, enrolled_str;
            getline(ss, code, '|');
            getline(ss, name, '|');
            getline(ss, credits_str, '|');
            getline(ss, capacity_str, '|');
            getline(ss, enrolled_str, '|');
            
            if (!code.empty()) {
                Course c(code, name, stoi(credits_str), stoi(capacity_str));
                c.enrolled = stoi(enrolled_str);
                courses.push_back(c);
            }
        }
        file.close();
        cout << "Courses loaded from " << filename << "\n";
    }
};

// =============== STUDENT PORTAL SYSTEM ===============
class StudentPortal {
private:
    StudentList students;
    vector<Course> courses;
    stack<UndoOperation> undoStack;
    StudentBST bst;
    string currentStudentId;

    int findCourseIndex(string code) {
        for (int i = 0; i < courses.size(); i++) {
            if (courses[i].code == code) {
                return i;
            }
        }
        return -1;
    }

    void addSampleData() {
        if (students.getCount() > 0) {
            return;
        }
        
        students.addStudent("241944", "Jibran Ahmed", "jibran@uni.edu", 3.8, 3);
        students.addStudent("S002", "Fatima Khan", "fatima@uni.edu", 3.9, 4);
        students.addStudent("S003", "Hassan Malik", "hassan@uni.edu", 3.5, 2);
        students.addStudent("S004", "Ayesha Raza", "ayesha@uni.edu", 3.7, 3);
        students.addStudent("S005", "Usman Ali", "usman@uni.edu", 3.6, 2);

        courses.push_back(Course("CS101", "Introduction to Programming", 3, 30));
        courses.push_back(Course("CS201", "Data Structures", 3, 2));
        courses.push_back(Course("CS301", "Algorithms", 3, 20));
        courses.push_back(Course("CS401", "Artificial Intelligence", 3, 15));

        courses[1].prerequisites.push_back("CS101");
        courses[2].prerequisites.push_back("CS201");
        courses[3].prerequisites.push_back("CS301");

        currentStudentId = "241944";
    }

public:
    StudentPortal() {
        addSampleData();
    }

    void showMainMenu() {
        cout << "\n============================================\n";
        cout << "     STUDENT PORTAL SYSTEM\n";
        cout << "     [Linked List + Stack + Queue + BST + File I/O]\n";
        cout << "============================================\n";
        cout << "\n1. View Profile\n";
        cout << "2. Student Management\n";
        cout << "3. Course Management\n";
        cout << "4. Enroll in Course (with Waitlist)\n";
        cout << "5. View My Enrollments\n";
        cout << "6. Drop Course\n";
        cout << "7. Undo Last Action (Stack)\n";
        cout << "8. View Course Waitlist (Queue)\n";
        cout << "9. Top 10 Students (BST Ranking)\n";
        cout << "10. Save Data (File I/O)\n";
        cout << "11. Load Data (File I/O)\n";
        cout << "0. Exit\n";
        cout << "============================================\n";
        cout << "Enter choice: ";
    }

    void viewProfile() {
        StudentNode* student = students.findStudent(currentStudentId);
        if (student != nullptr) {
            student->display();
        } else {
            cout << "Error: Student not found!\n";
        }
        cout << "Press Enter to continue..."; 
        cin.ignore();
        cin.get();
    }

    void studentManagement() {
        while (true) {
            cout << "\n========== STUDENT MANAGEMENT ==========\n";
            cout << "1. Add Student\n";
            cout << "2. Search Student\n";
            cout << "3. Update Student\n";
            cout << "4. Delete Student\n";
            cout << "5. Display All Students\n";
            cout << "0. Back\n";
            cout << "Enter choice: ";
            
            int choice;
            cin >> choice;

            if (choice == 1) {
                string id, name, email;
                double cgpa;
                int sem;
                cout << "\nStudent ID: "; 
                cin >> id;
                cin.ignore();
                cout << "Name: "; 
                getline(cin, name);
                cout << "Email: "; 
                cin >> email;
                cout << "CGPA: "; 
                cin >> cgpa;
                cout << "Semester: "; 
                cin >> sem;
                
                students.addStudent(id, name, email, cgpa, sem);
                cout << "Student added successfully!\n";
            }
            else if (choice == 2) {
                string id;
                cout << "\nEnter Student ID: "; 
                cin >> id;
                StudentNode* student = students.findStudent(id);
                if (student != nullptr) {
                    student->display();
                } else {
                    cout << "Student not found!\n";
                }
            }
            else if (choice == 3) {
                string id;
                cout << "\nEnter Student ID: "; 
                cin >> id;
                StudentNode* student = students.findStudent(id);
                if (student != nullptr) {
                    cout << "New CGPA: "; 
                    cin >> student->cgpa;
                    cout << "New Semester: "; 
                    cin >> student->semester;
                    cout << "Student updated!\n";
                } else {
                    cout << "Student not found!\n";
                }
            }
            else if (choice == 4) {
                string id;
                cout << "\nEnter Student ID: "; 
                cin >> id;
                if (students.deleteStudent(id)) {
                    cout << "Student deleted!\n";
                } else {
                    cout << "Student not found!\n";
                }
            }
            else if (choice == 5) {
                cout << "\n========== ALL STUDENTS ==========\n";
                students.displayAll();
            }
            else if (choice == 0) {
                break;
            }
        }
    }

    void courseManagement() {
        while (true) {
            cout << "\n========== COURSE MANAGEMENT ==========\n";
            cout << "1. Add Course\n";
            cout << "2. Display All Courses\n";
            cout << "3. Add Prerequisites\n";
            cout << "0. Back\n";
            cout << "Enter choice: ";
            
            int choice;
            cin >> choice;

            if (choice == 1) {
                string code, name;
                int credits, capacity;
                cout << "\nCourse Code: "; 
                cin >> code;
                cin.ignore();
                cout << "Course Name: "; 
                getline(cin, name);
                cout << "Credits: "; 
                cin >> credits;
                cout << "Capacity: "; 
                cin >> capacity;
                
                courses.push_back(Course(code, name, credits, capacity));
                cout << "Course added!\n";
            }
            else if (choice == 2) {
                cout << "\n========== ALL COURSES ==========\n";
                for (int i = 0; i < courses.size(); i++) {
                    courses[i].display();
                    cout << "\n";
                }
            }
            else if (choice == 3) {
                string course, prereq;
                cout << "\nCourse Code: "; 
                cin >> course;
                cout << "Prerequisite Code: "; 
                cin >> prereq;
                
                int courseIdx = findCourseIndex(course);
                int prereqIdx = findCourseIndex(prereq);
                
                if (courseIdx != -1 && prereqIdx != -1) {
                    courses[courseIdx].prerequisites.push_back(prereq);
                    cout << "Prerequisite added!\n";
                } else {
                    cout << "Course not found!\n";
                }
            }
            else if (choice == 0) {
                break;
            }
        }
    }

    void enrollInCourse() {
        StudentNode* student = students.findStudent(currentStudentId);
        if (student == nullptr) {
            cout << "Student not found!\n";
            return;
        }

        cout << "\n========== ENROLL IN COURSE ==========\n";
        cout << "Available Courses:\n";
        for (int i = 0; i < courses.size(); i++) {
            courses[i].display();
        }

        cout << "\nEnter Course Code: ";
        string code;
        cin >> code;

        int courseIdx = findCourseIndex(code);
        if (courseIdx == -1) {
            cout << "Course not found!\n";
            return;
        }

        bool canEnroll = true;
        vector<string>& prereqs = courses[courseIdx].prerequisites;
        
        for (int i = 0; i < prereqs.size(); i++) {
            string prereq = prereqs[i];
            bool found = false;
            
            for (int j = 0; j < student->enrolledCourses.size(); j++) {
                if (student->enrolledCourses[j] == prereq) {
                    found = true;
                    break;
                }
            }
            
            if (!found) {
                cout << "Prerequisites not met! Need: " << prereq << "\n";
                canEnroll = false;
                break;
            }
        }

        if (!canEnroll) {
            return;
        }

        if (courses[courseIdx].isFull()) {
            courses[courseIdx].addToWaitlist(currentStudentId);
            return;
        }

        student->enrolledCourses.push_back(code);
        courses[courseIdx].enrolled++;
        
        UndoOperation op;
        op.type = "ENROLL";
        op.studentId = currentStudentId;
        op.courseCode = code;
        undoStack.push(op);
        
        cout << "Enrolled successfully!\n";
    }

    void viewEnrollments() {
        StudentNode* student = students.findStudent(currentStudentId);
        if (student == nullptr || student->enrolledCourses.size() == 0) {
            cout << "\nNo courses enrolled.\n";
            return;
        }

        cout << "\n========== MY ENROLLED COURSES ==========\n";
        for (int i = 0; i < student->enrolledCourses.size(); i++) {
            string code = student->enrolledCourses[i];
            int courseIdx = findCourseIndex(code);
            if (courseIdx != -1) {
                courses[courseIdx].display();
                cout << "\n";
            }
        }
    }

    void dropCourse() {
        StudentNode* student = students.findStudent(currentStudentId);
        if (student == nullptr || student->enrolledCourses.size() == 0) {
            cout << "\nYou are not enrolled in any courses.\n";
            return;
        }

        cout << "\n========== DROP COURSE ==========\n";
        cout << "Your Courses:\n";
        for (int i = 0; i < student->enrolledCourses.size(); i++) {
            cout << (i + 1) << ". " << student->enrolledCourses[i] << "\n";
        }

        cout << "\nEnter Course Code to drop: ";
        string code;
        cin >> code;

        bool found = false;
        for (int i = 0; i < student->enrolledCourses.size(); i++) {
            if (student->enrolledCourses[i] == code) {
                student->enrolledCourses.erase(student->enrolledCourses.begin() + i);
                int courseIdx = findCourseIndex(code);
                if (courseIdx != -1) {
                    courses[courseIdx].enrolled--;
                    
                    string nextStudent = courses[courseIdx].getNextFromWaitlist();
                    if (nextStudent != "") {
                        StudentNode* waitlistStudent = students.findStudent(nextStudent);
                        if (waitlistStudent != nullptr) {
                            waitlistStudent->enrolledCourses.push_back(code);
                            courses[courseIdx].enrolled++;
                            cout << "Student " << nextStudent << " moved from waitlist to enrolled!\n";
                        }
                    }
                }
                
                UndoOperation op;
                op.type = "DROP";
                op.studentId = currentStudentId;
                op.courseCode = code;
                undoStack.push(op);
                
                cout << "Course dropped!\n";
                found = true;
                break;
            }
        }
        
        if (!found) {
            cout << "You are not enrolled in this course!\n";
        }
    }

    void undoLastAction() {
        if (undoStack.empty()) {
            cout << "\nNo actions to undo!\n";
            return;
        }

        UndoOperation op = undoStack.top();
        undoStack.pop();

        StudentNode* student = students.findStudent(op.studentId);
        if (student == nullptr) {
            cout << "Student not found!\n";
            return;
        }

        int courseIdx = findCourseIndex(op.courseCode);
        if (courseIdx == -1) {
            cout << "Course not found!\n";
            return;
        }

        if (op.type == "ENROLL") {
            for (int i = 0; i < student->enrolledCourses.size(); i++) {
                if (student->enrolledCourses[i] == op.courseCode) {
                    student->enrolledCourses.erase(student->enrolledCourses.begin() + i);
                    courses[courseIdx].enrolled--;
                    cout << "Undo: Enrollment in " << op.courseCode << " cancelled!\n";
                    break;
                }
            }
        } else if (op.type == "DROP") {
            student->enrolledCourses.push_back(op.courseCode);
            courses[courseIdx].enrolled++;
            cout << "Undo: Re-enrolled in " << op.courseCode << "!\n";
        }
    }

    void viewCourseWaitlist() {
        cout << "\n========== COURSE WAITLIST ==========\n";
        cout << "Enter Course Code: ";
        string code;
        cin >> code;

        int courseIdx = findCourseIndex(code);
        if (courseIdx == -1) {
            cout << "Course not found!\n";
            return;
        }

        cout << "\nCourse: " << code << "\n";
        cout << "Enrolled: " << courses[courseIdx].enrolled << "/" << courses[courseIdx].capacity << "\n";
        cout << "Waitlist Size: " << courses[courseIdx].waitlist.size() << " students\n";
    }

    void viewTopStudents() {
        cout << "\n========== TOP 10 STUDENTS (BY CGPA) - USING BST ==========\n";
        
        bst.clear();
        StudentNode* temp = students.head;
        while (temp != nullptr) {
            bst.insert(temp->id, temp->name, temp->cgpa);
            temp = temp->next;
        }

        auto topStudents = bst.getTop10();
        int rank = 1;
        for (auto& p : topStudents) {
            cout << rank << ". " << p.first << " - CGPA: " 
                 << fixed << setprecision(2) << p.second << "\n";
            rank++;
        }
    }

    void saveData() {
        FileManager::saveStudents(students, "students.txt");
        FileManager::saveCourses(courses, "courses.txt");
    }

    void loadData() {
        students.~StudentList();
        new (&students) StudentList();
        courses.clear();
        FileManager::loadStudents(students, "students.txt");
        FileManager::loadCourses(courses, "courses.txt");
    }

    void run() {
        while (true) {
            showMainMenu();
            
            int choice;
            cin >> choice;

            if (choice == 1) {
                viewProfile();
            }
            else if (choice == 2) {
                studentManagement();
            }
            else if (choice == 3) {
                courseManagement();
            }
            else if (choice == 4) {
                enrollInCourse();
            }
            else if (choice == 5) {
                viewEnrollments();
            }
            else if (choice == 6) {
                dropCourse();
            }
            else if (choice == 7) {
                undoLastAction();
            }
            else if (choice == 8) {
                viewCourseWaitlist();
            }
            else if (choice == 9) {
                viewTopStudents();
            }
            else if (choice == 10) {
                saveData();
            }
            else if (choice == 11) {
                loadData();
            }
            else if (choice == 0) {
                cout << "\nThank you for using Student Portal System!\n";
                return;
            }
            else {
                cout << "Invalid choice! Try again.\n";
            }
        }
    }
};

// =============== MAIN FUNCTION ===============
int main() {
    StudentPortal portal;
    portal.run();
    return 0;
}